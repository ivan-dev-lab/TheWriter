"""UI layer for TheWriter."""

